# CatTeleportMod-Fabric
Little mod to help you count seconds on cat-powered teleport